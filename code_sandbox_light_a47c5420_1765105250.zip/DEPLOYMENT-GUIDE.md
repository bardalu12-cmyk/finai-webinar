# 🚀 מדריך פרסום דף הנחיתה - FinAI

## קבצים להעלאה

העלה את הקבצים הבאים ל-Netlify:
- `index.html` - הדף הראשי
- `style.css` - העיצוב (גיבוי)
- `main.js` - הסקריפט (גיבוי)

**שים לב:** ה-CSS וה-JavaScript כבר מוטמעים בתוך `index.html`, אז הדף יעבוד גם בלי הקבצים הנוספים!

---

## 🌐 פרסום ל-Netlify

### צעד 1: העלאה
1. גש ל-[netlify.com](https://www.netlify.com)
2. הירשם (חינם!)
3. לחץ על **"Add new site"** → **"Deploy manually"**
4. גרור את התיקייה עם הקבצים (או קובץ ZIP)
5. הדף יעלה תוך שניות!

### צעד 2: חיבור דומיין
1. לחץ על **"Domain settings"**
2. לחץ על **"Add custom domain"**
3. הכנס: `webinar.myfinai.co.il`
4. Netlify ייתן לך CNAME record (משהו כמו `your-site.netlify.app`)

### צעד 3: הגדרה ב-Live DNS (Namecheap)
1. היכנס ל-Namecheap
2. לך ל-**Domain List** → בחר `myfinai.co.il`
3. לחץ **"Manage"** → **"Advanced DNS"**
4. לחץ **"Add New Record"**

הוסף:
```
Type: CNAME Record
Host: webinar
Value: [הערך שNetlify נתן לך]
TTL: Automatic
```

5. שמור!
6. חכה 5-30 דקות

### צעד 4: הפעלת SSL ב-Netlify
1. חזור ל-Netlify
2. לך ל-**Domain settings**
3. לחץ על **"Verify DNS configuration"**
4. אחרי שהוא מאמת, SSL יופעל אוטומטית!

---

## ✅ סיימת!

הדף שלך יהיה זמין ב:
**https://webinar.myfinai.co.il**

---

## 🔧 עדכונים עתידיים

כדי לעדכן את הדף:
1. ערוך את `index.html`
2. גרור אותו שוב ל-Netlify (או השתמש ב-Netlify CLI)
3. העדכון יעלה תוך שניות!

---

## 📊 צפייה בלידים

הלידים נשמרים בטבלה `webinar_leads`.
תוכל לצפות בהם דרך הפלטפורמה או לייצא לאקסל.

---

## 💡 עזרה?

אם משהו לא עובד:
1. בדוק שה-CNAME ב-Live DNS נכון
2. חכה עוד כמה דקות (DNS לוקח זמן)
3. נסה לפתוח במצב פרטי (Private/Incognito)
4. רענן עם Ctrl+F5 (או Cmd+Shift+R במק)

---

**בהצלחה! 🎉**