/**
 * FinAI Landing Page - Contact Form Handler
 * Handles form submission and saves data to the database
 */

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.getElementById('contactForm');
    const formMessage = document.getElementById('formMessage');
    const submitBtn = contactForm.querySelector('.submit-btn');
    const btnText = submitBtn.querySelector('.btn-text');

    // Form submission handler
    contactForm.addEventListener('submit', async function(e) {
        e.preventDefault();

        // Get form data
        const formData = {
            fullName: document.getElementById('fullName').value.trim(),
            phone: document.getElementById('phone').value.trim(),
            email: document.getElementById('email').value.trim(),
            submittedAt: new Date().toISOString()
        };

        // Validate form data
        if (!validateForm(formData)) {
            showMessage('אנא מלא את כל השדות בצורה תקינה', 'error');
            return;
        }

        // Disable submit button
        submitBtn.disabled = true;
        btnText.textContent = 'שולח...';

        try {
            // Send data to API
            const response = await fetch('tables/webinar_leads', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                // Success
                showMessage('תודה! קיבלנו את הפרטים שלך ונחזור אליך בהקדם', 'success');
                contactForm.reset();
                
                // Optional: Redirect after success (uncomment if needed)
                // setTimeout(() => {
                //     window.location.href = 'thank-you.html';
                // }, 2000);
            } else {
                // Error from server
                const errorData = await response.json();
                console.error('Server error:', errorData);
                showMessage('אירעה שגיאה בשליחת הטופס. אנא נסה שוב מאוחר יותר.', 'error');
            }
        } catch (error) {
            // Network or other error
            console.error('Error submitting form:', error);
            showMessage('אירעה שגיאת תקשורת. אנא בדוק את החיבור לאינטרנט ונסה שוב.', 'error');
        } finally {
            // Re-enable submit button
            submitBtn.disabled = false;
            btnText.textContent = 'שליחה';
        }
    });

    /**
     * Validate form data
     * @param {Object} data - Form data to validate
     * @returns {boolean} - True if valid, false otherwise
     */
    function validateForm(data) {
        // Validate full name (at least 2 characters)
        if (!data.fullName || data.fullName.length < 2) {
            return false;
        }

        // Validate phone (Israeli phone format)
        const phoneRegex = /^0(5[0-9]|[2-4]|[8-9])[0-9]{7}$/;
        const cleanPhone = data.phone.replace(/[-\s]/g, '');
        if (!phoneRegex.test(cleanPhone)) {
            return false;
        }

        // Validate email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(data.email)) {
            return false;
        }

        return true;
    }

    /**
     * Show message to user
     * @param {string} message - Message to display
     * @param {string} type - Type of message ('success' or 'error')
     */
    function showMessage(message, type) {
        formMessage.textContent = message;
        formMessage.className = `form-message ${type}`;
        
        // Auto-hide success message after 5 seconds
        if (type === 'success') {
            setTimeout(() => {
                formMessage.className = 'form-message';
            }, 5000);
        }
    }

    /**
     * Add input formatting for phone number
     */
    const phoneInput = document.getElementById('phone');
    phoneInput.addEventListener('input', function(e) {
        let value = e.target.value.replace(/\D/g, '');
        
        // Limit to 10 digits
        if (value.length > 10) {
            value = value.slice(0, 10);
        }
        
        // Format as XXX-XXXXXXX
        if (value.length > 3) {
            value = value.slice(0, 3) + '-' + value.slice(3);
        }
        
        e.target.value = value;
    });

    /**
     * Add smooth scroll animation for better UX
     */
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    /**
     * Add input focus effects
     */
    const inputs = contactForm.querySelectorAll('input');
    inputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.style.transform = 'scale(1.02)';
            this.parentElement.style.transition = 'transform 0.2s ease';
        });

        input.addEventListener('blur', function() {
            this.parentElement.style.transform = 'scale(1)';
        });
    });
});

/**
 * Add console message for developers
 */
console.log('%c🚀 FinAI Landing Page', 'color: #2563eb; font-size: 20px; font-weight: bold;');
console.log('%cDeveloped with ❤️ for FinAI', 'color: #6b7280; font-size: 14px;');